const API = "/api/v1";
const TOKEN_KEY = "fileshare_token";
const USER_KEY = "fileshare_user";

let token = sessionStorage.getItem(TOKEN_KEY);
let currentUser = null;
let currentPath = "/";
let canWrite = false;
let chunkSize = 8 * 1024 * 1024;
let maxParallel = 4;

const $ = (id) => document.getElementById(id);

function show(el) { el.classList.remove("hidden"); }
function hide(el) { el.classList.add("hidden"); }

async function api(path, options = {}) {
  const headers = { ...(options.headers || {}) };
  if (token) headers.Authorization = `Bearer ${token}`;
  if (!(options.body instanceof FormData) && options.body && !headers["Content-Type"]) {
    headers["Content-Type"] = "application/json";
  }
  const res = await fetch(API + path, { ...options, headers });
  if (res.status === 401) {
    logout();
    throw new Error("Session expired");
  }
  const text = await res.text();
  let data = null;
  try { data = text ? JSON.parse(text) : null; } catch { data = { detail: text }; }
  if (!res.ok) {
    const msg = data?.detail || (typeof data?.detail === "string" ? data.detail : res.statusText);
    throw new Error(Array.isArray(msg) ? msg.map((m) => m.msg || m).join(", ") : String(msg || res.status));
  }
  return data;
}

function formatSize(bytes) {
  if (bytes == null) return "";
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  return `${(bytes / (1024 * 1024 * 1024)).toFixed(2)} GB`;
}

function iconFor(entry) {
  if (entry.type === "directory") return "📁";
  if (entry.type === "image") return "🖼";
  if (entry.type === "video") return "🎬";
  return "📄";
}

function logout() {
  token = null;
  currentUser = null;
  sessionStorage.removeItem(TOKEN_KEY);
  sessionStorage.removeItem(USER_KEY);
  hide($("browser-view"));
  show($("login-view"));
}

async function login(username, password) {
  const data = await api("/auth/login", {
    method: "POST",
    body: JSON.stringify({ username, password }),
  });
  token = data.access_token;
  sessionStorage.setItem(TOKEN_KEY, token);
  currentUser = { username: data.username, is_admin: data.is_admin };
  sessionStorage.setItem(USER_KEY, JSON.stringify(currentUser));
  await openBrowser();
}

async function openBrowser() {
  hide($("login-view"));
  show($("browser-view"));
  currentPath = "/";
  await loadDirectory(currentPath);
}

async function loadDirectory(path) {
  currentPath = path || "/";
  $("current-path").textContent = currentPath;
  $("back-btn").classList.toggle("hidden", currentPath === "/" || currentPath === "");

  const data = await api(`/files?path=${encodeURIComponent(currentPath)}`);
  canWrite = data.can_write;
  $("mkdir-btn").classList.toggle("hidden", !canWrite);
  document.querySelector(".upload-btn").classList.toggle("hidden", !canWrite);

  const list = $("file-list");
  list.innerHTML = "";

  const entries = (data.entries || []).sort((a, b) => {
    if (a.type === "directory" && b.type !== "directory") return -1;
    if (b.type === "directory" && a.type !== "directory") return 1;
    return a.name.localeCompare(b.name);
  });

  if (entries.length === 0) {
    show($("empty-msg"));
  } else {
    hide($("empty-msg"));
  }

  for (const entry of entries) {
    const li = document.createElement("li");
    const isDir = entry.type === "directory";

    li.innerHTML = `
      <span class="icon">${iconFor(entry)}</span>
      <span class="meta">
        <span class="name">${escapeHtml(entry.name)}</span>
        <span class="detail">${isDir ? "Folder" : formatSize(entry.size)}</span>
      </span>
      <span class="actions"></span>
    `;

    const actions = li.querySelector(".actions");

    if (!isDir) {
      const dl = document.createElement("a");
      dl.textContent = "Get";
      dl.href = `${API}/files/download?path=${encodeURIComponent(entry.path)}`;
      dl.addEventListener("click", (e) => {
        e.stopPropagation();
        downloadWithAuth(entry.path, entry.name);
      });
      actions.appendChild(dl);
    }

    if (canWrite && !isDir) {
      const del = document.createElement("button");
      del.type = "button";
      del.textContent = "Del";
      del.addEventListener("click", async (e) => {
        e.stopPropagation();
        if (!confirm(`Delete ${entry.name}?`)) return;
        await api(`/files?path=${encodeURIComponent(entry.path)}`, { method: "DELETE" });
        await loadDirectory(currentPath);
      });
      actions.appendChild(del);
    }

    li.addEventListener("click", () => {
      if (isDir) loadDirectory(entry.path);
    });

    list.appendChild(li);
  }
}

function escapeHtml(s) {
  const d = document.createElement("div");
  d.textContent = s;
  return d.innerHTML;
}

async function downloadWithAuth(path, filename) {
  const res = await fetch(
    `${API}/files/download?path=${encodeURIComponent(path)}`,
    { headers: { Authorization: `Bearer ${token}` } }
  );
  if (!res.ok) {
    alert("Download failed");
    return;
  }
  const blob = await res.blob();
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

async function uploadFile(file, onProgress) {
  if (file.size > chunkSize) {
    return uploadMultipart(file, onProgress);
  }
  const form = new FormData();
  form.append("file", file);
  const res = await fetch(
    `${API}/files/upload?path=${encodeURIComponent(currentPath)}`,
    {
      method: "POST",
      headers: { Authorization: `Bearer ${token}` },
      body: form,
    }
  );
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || "Upload failed");
  }
  onProgress(1);
  return res.json();
}

async function uploadMultipart(file, onProgress) {
  const init = await api("/files/uploads", {
    method: "POST",
    body: JSON.stringify({
      path: currentPath,
      filename: file.name,
      total_size: file.size,
    }),
  });

  chunkSize = init.chunk_size;
  const totalParts = init.total_parts;
  const uploadId = init.upload_id;

  let status = await api(`/files/uploads/${uploadId}`);
  const done = new Set(status.parts_received || []);

  const parts = [];
  for (let n = 1; n <= totalParts; n++) {
    if (!done.has(n)) parts.push(n);
  }

  let completed = done.size;

  async function uploadPart(partNumber) {
    const start = (partNumber - 1) * chunkSize;
    const end = Math.min(start + chunkSize, file.size);
    const blob = file.slice(start, end);

    const res = await fetch(
      `${API}/files/uploads/${uploadId}/parts/${partNumber}`,
      {
        method: "PUT",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/octet-stream",
        },
        body: blob,
      }
    );
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.detail || `Part ${partNumber} failed`);
    }
    completed++;
    onProgress(completed / totalParts);
    return res.json();
  }

  const queue = [...parts];
  const workers = Array.from({ length: Math.min(maxParallel, queue.length || 1) }, async () => {
    while (queue.length) {
      const part = queue.shift();
      await uploadPart(part);
    }
  });
  await Promise.all(workers);

  return api(`/files/uploads/${uploadId}/complete`, { method: "POST" });
}

async function handleFiles(fileList) {
  if (!canWrite) {
    alert("You do not have write access to this folder");
    return;
  }
  const files = Array.from(fileList);
  if (!files.length) return;

  const prog = $("upload-progress");
  show(prog);

  for (let i = 0; i < files.length; i++) {
    const file = files[i];
    prog.textContent = `Uploading ${i + 1}/${files.length}: ${file.name}`;
    try {
      await uploadFile(file, (p) => {
        prog.textContent = `${file.name}: ${Math.round(p * 100)}%`;
      });
    } catch (e) {
      alert(`${file.name}: ${e.message}`);
    }
  }

  hide(prog);
  await loadDirectory(currentPath);
}

$("login-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const err = $("login-error");
  hide(err);
  try {
    await login($("username").value.trim(), $("password").value);
  } catch (ex) {
    err.textContent = ex.message;
    show(err);
  }
});

$("logout-btn").addEventListener("click", logout);

$("back-btn").addEventListener("click", () => {
  const p = currentPath.replace(/\/$/, "") || "/";
  const parent = p === "/" ? "/" : p.substring(0, p.lastIndexOf("/")) || "/";
  loadDirectory(parent);
});

$("file-input").addEventListener("change", (e) => {
  handleFiles(e.target.files);
  e.target.value = "";
});

$("mkdir-btn").addEventListener("click", async () => {
  const name = prompt("Folder name:");
  if (!name) return;
  const path = `${currentPath.replace(/\/$/, "")}/${name}`.replace("//", "/");
  await api(`/files/mkdir?path=${encodeURIComponent(path)}`, { method: "POST" });
  await loadDirectory(currentPath);
});

const dropZone = $("drop-zone");
if ("draggable" in document.createElement("div")) {
  show(dropZone);
  ["dragenter", "dragover"].forEach((ev) => {
    document.addEventListener(ev, (e) => {
      e.preventDefault();
      dropZone.classList.add("active");
    });
  });
  ["dragleave", "drop"].forEach((ev) => {
    document.addEventListener(ev, (e) => {
      e.preventDefault();
      dropZone.classList.remove("active");
      if (ev === "drop" && e.dataTransfer?.files?.length) {
        handleFiles(e.dataTransfer.files);
      }
    });
  });
}

(async function init() {
  if (token) {
    try {
      const me = await api("/auth/me");
      currentUser = me;
      await openBrowser();
    } catch {
      logout();
    }
  }
})();
